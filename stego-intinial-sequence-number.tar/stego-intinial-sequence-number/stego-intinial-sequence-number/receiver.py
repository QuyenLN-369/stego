
from scapy.all import *
import sys

KEY = 0x42  

def decode_pcap(pcap_file):
    packets = rdpcap(pcap_file)
    message = b""
    packet_count = 0  
    
    for pkt in packets:
        if (TCP in pkt and 
            pkt[TCP].flags == 0x02 and  
            pkt[TCP].dport == 80 and    
            pkt[IP].ttl == 64):         
            
            raw = pkt[TCP].seq.to_bytes(4, 'big')
            print(f"[+] Found data packet with seq: {raw.hex()}")
            message += raw
            packet_count += 1
    
    if not message:
        error_msg = "No valid packets found. Check:\n- SYN packets\n- Port 80\n- TTL=64"
        print(f"[-] {error_msg}")
        return None, 0
    
    
    decrypted = bytes([b ^ KEY for b in message])
    decrypted = decrypted.rstrip(b'\x00')
    
    try:
        return decrypted.decode('ascii'), packet_count
    except UnicodeDecodeError:
        return f"[ERROR] Invalid decryption. Raw: {decrypted.hex()}", packet_count

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python3 receiver.py <pcap_file> <output_msg_file> <output_count_file>")
        sys.exit(1)
    
    pcap_file = sys.argv[1]
    output_msg_file = sys.argv[2]
    output_count_file = sys.argv[3]

    try:
        msg, count = decode_pcap(pcap_file)

        with open(output_msg_file, "w") as f_msg:
            if msg and not msg.startswith("[ERROR]"):
                f_msg.write(msg)
                print(f"[+] Successfully decoded message: {msg}")
            else:
                f_msg.write(msg if msg else "Decode failed")
                print(f"[-] {msg if msg else 'Decode failed'}")
 
        with open(output_count_file, "w") as f_count:
            f_count.write(str(count))
            print(f"[i] Data packets used: {count}")
    except Exception as e:
        print(f"Error: {str(e)}")