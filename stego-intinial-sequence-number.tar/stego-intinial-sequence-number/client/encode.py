
import sys

KEY = 0x42 

def encode_message_to_sequences(message):
    message_bytes = message.encode('ascii')
 
    encrypted_bytes = bytes([b ^ KEY for b in message_bytes])
    sequences = []

    for i in range(0, len(encrypted_bytes), 4):
        chunk = encrypted_bytes[i:i+4]
        while len(chunk) < 4:
            chunk += b'\x00'
        seq = int.from_bytes(chunk, 'big')
        sequences.append(seq)

    return sequences

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 encode.py <input_file> <output_file>")
        sys.exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2]

    try:
        with open(input_file, "r") as f:
            message = f.read().strip()  
        sequences = encode_message_to_sequences(message)

        with open(output_file, "w") as f:
            for seq in sequences:
                f.write(str(seq) + "\n")
        print(f"[+] Encoded message from {input_file} to {len(sequences)} sequence numbers, saved to {output_file}")
    except FileNotFoundError:
        print(f"Error: File {input_file} not found.")
    except Exception as e:
        print(f"Error: {str(e)}")