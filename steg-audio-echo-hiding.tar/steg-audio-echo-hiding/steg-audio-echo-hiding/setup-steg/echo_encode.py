import argparse
import numpy as np
import scipy.io.wavfile as wavfile

def text_to_bits(text):
    bits = []
    for char in text:
        binary = bin(ord(char))[2:].zfill(8)
        bits.extend([int(b) for b in binary])
    return bits

def add_echo(audio, delay, decay, message_bits, hop_size):
    output = audio.copy().astype(float)
    num_frames = len(audio) // hop_size
    message_bits = message_bits[:num_frames]
    
    for i in range(len(message_bits)):
        start = i * hop_size
        end = start + hop_size
        
        if end > len(audio):
            break
            
        frame = output[start:end]
        
        if message_bits[i] == 1:
            for j in range(len(frame)):
                if j + delay < len(frame):
                    frame[j + delay] += decay * frame[j]

        output[start:end] = frame

    output = np.clip(output, -32768, 32767).astype(np.int16)
    return output

def main():
    parser = argparse.ArgumentParser(description='Hide message in audio using echo.')
    parser.add_argument('input_audio', help='Path to input audio file')
    parser.add_argument('output_audio', help='Path to output audio file')
    parser.add_argument('message_file', help='Path to message text file')
    
    args = parser.parse_args()

    sample_rate, audio = wavfile.read(args.input_audio)
    if len(audio.shape) > 1:
        audio = np.mean(audio, axis=1).astype(np.int16)

    delay = 100      
    decay = 0.4      
    hop_size = 1024  

    with open(args.message_file, 'r', encoding='utf-8') as file:
        message = file.read()

    message_bits = text_to_bits(message)

    audio_with_echo = add_echo(audio, delay, decay, message_bits, hop_size)

    wavfile.write(args.output_audio, sample_rate, audio_with_echo)
    print(f"Đã giấu tin nhắn và lưu vào '{args.output_audio}'")

if __name__ == "__main__":
    main()

