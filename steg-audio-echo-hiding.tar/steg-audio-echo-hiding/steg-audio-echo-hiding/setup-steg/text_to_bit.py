def text_to_bits(text):
    return ''.join(format(ord(char), '08b') for char in text)

text = "Hello, this is a test text!"

bit_string = text_to_bits(text)

with open('/home/ubuntu/text_to_bit.txt', 'w') as file:
    file.write(bit_string)

print("Chuỗi bit đã được lưu vào /home/ubuntu/text_to_bit.txt")

