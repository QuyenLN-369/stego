import argparse
import numpy as np
import scipy.io.wavfile as wavfile
import matplotlib.pyplot as plt

def calculate_frequency_deviation(audio_file):
    sample_rate, audio_data = wavfile.read(audio_file)
    
    if len(audio_data.shape) > 1:
        audio_data = np.mean(audio_data, axis=1).astype(np.int16)

    hop_size = 1024  
    num_frames = len(audio_data) // hop_size

    frequencies = []

    for i in range(num_frames):
        start = i * hop_size
        end = start + hop_size
        
        if end > len(audio_data):
            break
            
        frame = audio_data[start:end]
        
        freqs = np.fft.fftfreq(len(frame), 1 / sample_rate)
        fft_values = np.fft.fft(frame)
        
        positive_freqs = freqs[:len(freqs)//2]
        positive_fft_values = np.abs(fft_values[:len(fft_values)//2])
        
        peak_freq = positive_freqs[np.argmax(positive_fft_values)]
        frequencies.append(peak_freq)
    
    return frequencies

def compare_audio_files(file1, file2):
    frequencies1 = calculate_frequency_deviation(file1)
    frequencies2 = calculate_frequency_deviation(file2)

    min_length = min(len(frequencies1), len(frequencies2))
    frequencies1 = frequencies1[:min_length]
    frequencies2 = frequencies2[:min_length]

    frequency_changes = np.abs(np.array(frequencies1) - np.array(frequencies2))

    percent_deviations = (frequency_changes / np.array(frequencies1)) * 100

    avg_deviation = np.mean(percent_deviations)
    
    print(f"So sánh giữa {file1} và {file2}:")
    for i in range(1, len(frequencies1)):
        print(f"Khung {i}:")
        print(f"- Tần số {file1}: {frequencies1[i]:.2f} Hz, Tần số {file2}: {frequencies2[i]:.2f} Hz")
        print(f"- Chênh lệch: {frequency_changes[i-1]:.2f} Hz, Độ lệch: {percent_deviations[i-1]:.2f}%")
    
    print(f"\nĐộ lệch trung bình: {avg_deviation:.2f}%")

    plt.figure(figsize=(10, 6))
    plt.plot(frequencies1, label=f"Tần số của {file1}")
    plt.plot(frequencies2, label=f"Tần số của {file2}")
    plt.title("So sánh tần số giữa hai file âm thanh")
    plt.xlabel("Khung thời gian")
    plt.ylabel("Tần số (Hz)")
    plt.legend()
    plt.grid(True)
    plt.show()

def main():
    parser = argparse.ArgumentParser(description='So sánh tần số giữa hai file âm thanh.')
    parser.add_argument('file1', help='Đường dẫn tới file âm thanh đầu tiên')
    parser.add_argument('file2', help='Đường dẫn tới file âm thanh thứ hai')
    
    args = parser.parse_args()

    compare_audio_files(args.file1, args.file2)

if __name__ == "__main__":
    main()

