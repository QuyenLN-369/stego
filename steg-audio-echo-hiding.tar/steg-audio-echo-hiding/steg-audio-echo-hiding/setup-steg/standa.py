import numpy as np
from scipy.io import wavfile

def tai_am_thanh(duong_dan):
    tan_so, du_lieu = wavfile.read(duong_dan)
    if du_lieu.ndim > 1:
        du_lieu = du_lieu[:, 0]  # Chuyển sang mono
    du_lieu = du_lieu / np.max(np.abs(du_lieu))  # Chuẩn hóa
    return tan_so, du_lieu

def luu_am_thanh(duong_dan, tan_so, du_lieu):
    du_lieu = np.int16(du_lieu * 32767)  # Chuyển về 16-bit
    wavfile.write(duong_dan, tan_so, du_lieu)

# Kiểm tra
tan_so, du_lieu = tai_am_thanh("/home/ubuntu/audio/plain.wav")
print("Standardization success")
luu_am_thanh("/home/ubuntu/audio/output_standa.wav", tan_so, du_lieu)
