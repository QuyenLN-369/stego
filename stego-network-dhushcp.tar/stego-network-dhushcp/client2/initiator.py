#!/usr/bin/env python3
# Copyright 2024-2025 © 0SINTr (https://github.com/0SINTr)
import os
import gc
import sys
import time
import uuid
import argparse
import threading
import subprocess
from scapy.all import *
from scapy.layers.dhcp import DHCP, BOOTP
from scapy.layers.inet import IP, UDP
from scapy.layers.l2 import Ether, get_if_hwaddr
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.exceptions import InvalidTag
from colorama import Fore, Style

try:
    from prompt_toolkit import PromptSession
    from prompt_toolkit.validation import Validator, ValidationError
    from prompt_toolkit.formatted_text import HTML
    from prompt_toolkit.key_binding import KeyBindings
except ImportError:
    print(Style.BRIGHT + "[ERROR] " + Style.RESET_ALL + "The 'prompt_toolkit' library is required. Install with 'sudo apt install python3-prompt-toolkit'.")
    sys.exit(1)

# Configuration Constants
DHCP_OPTION_ID = 224       # Custom DHCP option ID for DHushCP
SESSION_ID_OPTION = 225    # DHCP option for Session ID
DATA_OPTION = 226          # DHCP option for embedding data
DHUSHCP_ID = None          # Set in main()

MAX_MESSAGE_LENGTH = 100    # Maximum message length in characters
MAX_DHCP_OPTION_DATA = 255  # Maximum data per DHCP option
AES_KEY_SIZE = 32           # 256 bits for AES-256
NONCE_SIZE = 12             # 96 bits for AES-GCM nonce
CHECKSUM_SIZE = 32          # 256 bits for SHA-256 checksum

# Global variables
iface = None
session_id = None
private_key = None
public_key = None
shared_key_holder = {'key': None}
own_mac = None
stop_event = None
DHUSHCP_ID = None

def generate_session_id():
    """Generate a unique session identifier."""
    return uuid.uuid4().bytes  # 16 bytes

def get_network_interface():
    """Detect and select the active network interface (Ethernet or Wi-Fi)."""
    try:
        result = subprocess.run(['ip', 'link'], capture_output=True, text=True)
        lines = result.stdout.splitlines()
        interfaces = []
        for line in lines:
            if 'state ' in line and ': ' in line:
                iface_full = line.split(': ')[1].split()[0]
                iface = iface_full.split('@')[0]  # Remove @ifX part
                state = line.split('state ')[1].split()[0]
                if state == 'UP' and iface != 'lo':  # Skip loopback
                    interfaces.append(iface)

        if not interfaces:
            print(Style.BRIGHT + "[ERROR] " + Style.RESET_ALL + "No active network interface found. Exiting.")
            sys.exit(1)

        if len(interfaces) > 1:
            print(Style.BRIGHT + "[INPUT] " + Style.RESET_ALL + "Multiple active interfaces detected. Choose one:")
            for idx, iface in enumerate(interfaces):
                print(f"{idx + 1}. {iface}")
            choice = int(input(Style.BRIGHT + "[INPUT] " + Style.RESET_ALL + "Enter choice number: ")) - 1
            if choice < 0 or choice >= len(interfaces):
                print(Style.BRIGHT + "[ERROR] " + Style.RESET_ALL + "Invalid selection. Exiting.")
                sys.exit(1)
            selected_interface = interfaces[choice]
        else:
            selected_interface = interfaces[0]
            print(Style.BRIGHT + "[INFO] " + Style.RESET_ALL + f"Detected network interface: {selected_interface}")

        # Verify state with cleaned interface name
        state_check = subprocess.run(['ip', 'link', 'show', selected_interface], capture_output=True, text=True)
        if "state UP" in state_check.stdout:
            return selected_interface
        else:
            print(Style.BRIGHT + "[ERROR] " + Style.RESET_ALL + f"Interface {selected_interface} is DOWN. Bring it UP with 'sudo ip link set {selected_interface} up'.")
            sys.exit(1)
    except Exception as e:
        print(Style.BRIGHT + "[ERROR] " + Style.RESET_ALL + f"Failed to detect network interface: {e}")
        sys.exit(1)

def check_sudo():
    """Ensure script runs with sudo privileges."""
    if os.geteuid() != 0:
        print(Style.BRIGHT + "[INFO] " + Style.RESET_ALL + "Run with `sudo` for required privileges.")
        sys.exit(1)

def get_limited_input(prompt_message, max_length):
    global stop_event
    session = PromptSession()
    bindings = KeyBindings()

    @bindings.add('c-m')  # Enter key
    def _(event):
        buffer = event.app.current_buffer
        if len(buffer.text) > max_length:
            event.app.current_buffer.validation_state = False
            event.app.current_buffer.validate_and_handle()
        else:
            buffer.validate_and_handle()

    def bottom_toolbar():
        text_length = len(session.default_buffer.text)
        remaining = max_length - text_length
        return HTML(f'Remaining: <b><style bg="ansiyellow">{remaining}</style></b>')

    validator = Validator.from_callable(
        lambda text: len(text) <= max_length,
        error_message=f"Exceeds {max_length} characters.",
        move_cursor_to_end=True)

    try:
        user_input = session.prompt(
            HTML(prompt_message),
            validator=validator,
            validate_while_typing=False,
            key_bindings=bindings,
            bottom_toolbar=bottom_toolbar)
        return user_input
    except (ValidationError, EOFError, KeyboardInterrupt):
        stop_event.set()
        return None

def generate_ecc_keypair():
    """Generate ECC key pair using SECP384R1."""
    private_key = ec.generate_private_key(ec.SECP384R1())
    public_key = private_key.public_key()
    return private_key, public_key

def serialize_public_key(public_key):
    """Serialize public key to PEM format."""
    return public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )

def deserialize_public_key(pem_data):
    """Deserialize PEM-formatted public key."""
    return serialization.load_pem_public_key(pem_data)

def derive_shared_key(private_key, peer_public_key):
    """Derive shared AES key using ECDH and HKDF."""
    shared_secret = private_key.exchange(ec.ECDH(), peer_public_key)
    derived_key = HKDF(
        algorithm=hashes.SHA256(),
        length=AES_KEY_SIZE,
        salt=None,
        info=b'DHushCP-SharedKey',
    ).derive(shared_secret)
    return derived_key

def encrypt_message(aes_key, plaintext):
    """Encrypt plaintext with AES-GCM and append SHA-256 checksum."""
    digest = hashes.Hash(hashes.SHA256())
    digest.update(plaintext.encode())
    checksum = digest.finalize()

    aesgcm = AESGCM(aes_key)
    nonce = os.urandom(NONCE_SIZE)
    ciphertext = aesgcm.encrypt(nonce, plaintext.encode(), None)

    return nonce + ciphertext + checksum

def decrypt_message(aes_key, encrypted_package):
    """Decrypt ciphertext and verify SHA-256 checksum."""
    try:
        nonce = encrypted_package[:NONCE_SIZE]
        ciphertext = encrypted_package[NONCE_SIZE:-CHECKSUM_SIZE]
        received_checksum = encrypted_package[-CHECKSUM_SIZE:]

        aesgcm = AESGCM(aes_key)
        plaintext_bytes = aesgcm.decrypt(nonce, ciphertext, None)
        plaintext = plaintext_bytes.decode()

        digest = hashes.Hash(hashes.SHA256())
        digest.update(plaintext.encode())
        calculated_checksum = digest.finalize()

        if calculated_checksum != received_checksum:
            print(Style.BRIGHT + "<SAFETY> Checksum failed! Integrity compromised." + Style.RESET_ALL)
            return None
        return plaintext
    except (InvalidTag, Exception) as e:
        print(Style.BRIGHT + "[ERROR] " + Style.RESET_ALL + f"Decryption failed: {e}")
        return None

def embed_data_into_dhcp_option(data_bytes):
    """Embed data into DHCP option 226."""
    if len(data_bytes) > MAX_DHCP_OPTION_DATA:
        print(Style.BRIGHT + "[ERROR] " + Style.RESET_ALL + "Data exceeds 255 bytes.")
        return None
    return [(DATA_OPTION, data_bytes)]

def reassemble_data_from_dhcp_option(options):
    """Extract data from DHCP option 226."""
    for opt in options:
        if isinstance(opt, tuple) and opt[0] == DATA_OPTION:
            return opt[1]
    return None

def create_dhcp_discover(session_id, dhushcp_id, data_options=[]):
    """Create DHCP Discover packet with embedded data."""
    xid = RandInt()
    return (
        Ether(dst="ff:ff:ff:ff:ff:ff") /
        IP(src="0.0.0.0", dst="255.255.255.255") /
        UDP(sport=68, dport=67) /
        BOOTP(chaddr=get_if_hwaddr(iface), xid=xid, flags=0x8000) /
        DHCP(options=[
            ("message-type", "discover"),
            (DHCP_OPTION_ID, dhushcp_id),
            (SESSION_ID_OPTION, session_id),
        ] + data_options + [("end")])
    )

def send_dhcp_discover(packet, iface):
    """Send DHCP Discover packet."""
    sendp(packet, iface=iface, verbose=False)
    print(Style.BRIGHT + "[INFO] " + Style.RESET_ALL + "Sent DHCP Discover packet.")

def listen_dhcp_discover(iface, callback, stop_event):
    """Listen for DHCP Discover packets."""
    sniff(
        filter="udp and (port 67 or 68)",
        iface=iface,
        prn=callback,
        store=0,
        stop_filter=lambda pkt: stop_event.is_set()
    )

def initiate_key_exchange(iface, session_id, dhushcp_id, private_key):
    """Initiate key exchange by sending public key."""
    public_pem = serialize_public_key(private_key.public_key())
    options = embed_data_into_dhcp_option(public_pem)
    if options:
        packet = create_dhcp_discover(session_id, dhushcp_id, options)
        send_dhcp_discover(packet, iface)
        print(Style.BRIGHT + "[INFO] " + Style.RESET_ALL + "Initiated key exchange.")

def handle_received_dhcp(packet):
    """Handle received DHCP Discover packets."""
    global DHUSHCP_ID
    if DHCP in packet and packet[DHCP].options:
        dhcp_options = packet[DHCP].options
        option_dict = {opt[0]: opt[1] for opt in dhcp_options if isinstance(opt, tuple)}

        if Ether in packet and packet[Ether].src == own_mac:
            return

        if (DHCP_OPTION_ID in option_dict and option_dict[DHCP_OPTION_ID] == DHUSHCP_ID and
            SESSION_ID_OPTION in option_dict and option_dict[SESSION_ID_OPTION] == session_id):

            data_options = [opt for opt in dhcp_options if opt[0] == DATA_OPTION]
            if not data_options:
                return

            assembled_data = reassemble_data_from_dhcp_option(dhcp_options)
            if assembled_data:
                try:
                    peer_public_key = deserialize_public_key(assembled_data)
                    print(Style.BRIGHT + "[INFO] " + Style.RESET_ALL + "Received peer's public key.")
                    shared_key = derive_shared_key(private_key, peer_public_key)
                    shared_key_holder['key'] = shared_key
                    print(Style.BRIGHT + "[INFO] " + Style.RESET_ALL + "Derived shared key.")
                except Exception:
                    if shared_key_holder['key']:
                        plaintext = decrypt_message(shared_key_holder['key'], assembled_data)
                        if plaintext:
                            print(Style.BRIGHT + Fore.GREEN + "\n[MESSAGE RECEIVED] " + Style.RESET_ALL + f"{plaintext}\n")
                            user_reply = get_limited_input("-> Enter reply (max 100 chars, Ctrl+C to exit):\n", MAX_MESSAGE_LENGTH)
                            if user_reply:
                                encrypted_reply = encrypt_message(shared_key_holder['key'], user_reply)
                                options = embed_data_into_dhcp_option(encrypted_reply)
                                if options:
                                    reply_packet = create_dhcp_discover(session_id, DHUSHCP_ID, options)
                                    send_dhcp_discover(reply_packet, iface)
                                    print(Style.BRIGHT + "[INFO] " + Style.RESET_ALL + "Sent reply.")

def cleanup_process():
    """Perform cleanup of keys and logs."""
    print("\n[INFO] Initiating cleanup...")
    if input("Clean up? Deletes keys and logs (y/n): ").lower() != 'y':
        print(Style.BRIGHT + "[INFO] " + Style.RESET_ALL + "Cleanup aborted.")
        return

    try:
        private_key = None
        public_key = None
        shared_key_holder['key'] = None
        gc.collect()
        print(Style.BRIGHT + "[INFO] " + Style.RESET_ALL + "Keys deleted.")
    except Exception as e:
        print(Style.BRIGHT + "[ERROR] " + Style.RESET_ALL + f"Key deletion failed: {e}")

    try:
        print(Style.BRIGHT + "[INFO] " + Style.RESET_ALL + "Clearing logs...")
        for log in ['/var/log/syslog', '/var/log/auth.log']:
            if os.path.exists(log):
                subprocess.run(['truncate', '-s', '0', log], check=True)
        print(Style.BRIGHT + "[INFO] " + Style.RESET_ALL + "Logs cleared.")
    except Exception as e:
        print(Style.BRIGHT + "[ERROR] " + Style.RESET_ALL + f"Log clearing failed: {e}")

    try:
        os.system('clear' if os.name == 'posix' else 'cls')
        print(".")
    except Exception as e:
        print(Style.BRIGHT + "[ERROR] " + Style.RESET_ALL + f"Terminal clear failed: {e}")

def parse_arguments():
    parser = argparse.ArgumentParser(description='DHushCP Initiator')
    parser.add_argument('-i', '--id', type=str, required=True, help='DHushCP ID (shared secret)')
    return parser.parse_args()

def main():
    global iface, session_id, private_key, public_key, own_mac, DHUSHCP_ID, stop_event

    args = parse_arguments()
    DHUSHCP_ID = args.id.encode('utf-8')
    print(Style.BRIGHT + "\n<SAFETY> Use Ctrl+C to cleanup and exit.\n" + Style.RESET_ALL)
    check_sudo()
    iface = get_network_interface()
    own_mac = get_if_hwaddr(iface)
    session_id = generate_session_id()

    private_key, public_key = generate_ecc_keypair()
    print(Style.BRIGHT + "[INFO] " + Style.RESET_ALL + "Generated ECC key pair.")

    stop_event = threading.Event()

    listener_thread = threading.Thread(
        target=listen_dhcp_discover,
        args=(iface, handle_received_dhcp, stop_event)
    )
    listener_thread.daemon = True
    listener_thread.start()
    print(Style.BRIGHT + "[INFO] " + Style.RESET_ALL + "Listening for DHCP packets.")

    if input(Style.BRIGHT + "[INPUT] " + Style.RESET_ALL + "Initiate communication? (y/n): ").lower() == 'y':
        initiate_key_exchange(iface, session_id, DHUSHCP_ID, private_key)

    try:
        while shared_key_holder['key'] is None and not stop_event.is_set():
            time.sleep(1)
    except KeyboardInterrupt:
        stop_event.set()

    if stop_event.is_set():
        cleanup_process()
        sys.exit(0)

    user_message = get_limited_input("\n-> Enter message (max 100 chars, Ctrl+C to exit):\n", MAX_MESSAGE_LENGTH)
    if user_message:
        encrypted_message = encrypt_message(shared_key_holder['key'], user_message)
        options = embed_data_into_dhcp_option(encrypted_message)
        if options:
            packet = create_dhcp_discover(session_id, DHUSHCP_ID, options)
            send_dhcp_discover(packet, iface)
            print(Style.BRIGHT + "[INFO] " + Style.RESET_ALL + "Sent message.")
    else:
        cleanup_process()
        sys.exit(0)

    try:
        while not stop_event.is_set():
            time.sleep(1)
    except KeyboardInterrupt:
        stop_event.set()

    cleanup_process()
    sys.exit(0)

if __name__ == "__main__":
    main()