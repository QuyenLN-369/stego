import argparse
import json
import os
import subprocess
import paramiko
import threading
from scapy.all import sniff, ICMP, IP
from colorama import Fore, Style

# Constants
ARP_START = 201
ARP_END = 210
MAX_MESSAGE_LENGTH = 60
MAC_ADDRESS_FORMAT = "{}:{}:{}:{}:{}:{}"

def load_mapping():
    with open('char_to_mac.json', 'r') as file:
        return json.load(file)

def validate_message(message, mapping):
    allowed_chars = set(mapping.keys())
    if len(message) > MAX_MESSAGE_LENGTH:
        print(f"{Style.BRIGHT}[INFO]{Style.RESET_ALL} Message too long. Truncated to {MAX_MESSAGE_LENGTH} characters.")
        message = message[:MAX_MESSAGE_LENGTH]
    if not all(char in allowed_chars for char in message):
        print(f"{Style.BRIGHT}[ERROR]{Style.RESET_ALL} Invalid characters. Allowed: {', '.join(sorted(allowed_chars))}")
        return None
    return message

def encode_message(args):
    mapping = load_mapping()
    with open(args.input, 'r') as f:
        message = f.read().strip().lower()
    validated_message = validate_message(message, mapping)
    if not validated_message:
        return
    encoded = ''.join([mapping[char] for char in validated_message])
    mac_addresses = []
    for i in range(0, len(encoded), 12):
        chunk = encoded[i:i+12].ljust(12, '0')
        mac = MAC_ADDRESS_FORMAT.format(*[chunk[j:j+2] for j in range(0, 12, 2)])
        mac_addresses.append(mac)
    with open(args.output, 'w') as f:
        json.dump(mac_addresses, f)
    print(f"{Style.BRIGHT}[INFO]{Style.RESET_ALL} Encoded message saved to {args.output}")

def add_arp_entries(args):
    with open(args.encoded, 'r') as f:
        mac_addresses = json.load(f)
    for idx, mac in enumerate(mac_addresses, start=ARP_START):
        ip = f"{args.subnet}{idx}"
        command = ["sudo", "arp", "-s", ip, mac]
        subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    print(f"{Style.BRIGHT}[INFO]{Style.RESET_ALL} Added {len(mac_addresses)} ARP entries")

def send_ping(args):
    subprocess.run(["ping", "-c", "1", args.dest_ip],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    print(f"{Style.BRIGHT}[INFO]{Style.RESET_ALL} Ping sent to {args.dest_ip}")

def listen_for_ping(args, callback):
    def packet_callback(packet):
        if packet.haslayer(ICMP) and packet.haslayer(IP):
            if packet[IP].src == args.dest_ip:
                callback(args)
    sniff(filter="icmp", prn=packet_callback, store=0, timeout=60)

def read_arp(args):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        ssh.connect(args.dest_ip, username=args.ssh_user, password=args.ssh_pass)
        stdin, stdout, stderr = ssh.exec_command("arp -an")
        arp_output = stdout.read().decode()
        ssh.close()
        if not arp_output.strip():
            print(f"{Style.BRIGHT}[ERROR]{Style.RESET_ALL} No ARP entries found")
            return
        arp_entries = []
        for line in arp_output.splitlines():
            parts = line.split()
            if len(parts) >= 4:
                ip = parts[1].strip('()')
                if ip.startswith(args.subnet):
                    last_octet = int(ip.split('.')[-1])
                    if ARP_START <= last_octet <= ARP_END:
                        mac = parts[3].replace(':', '').upper()
                        arp_entries.append((ip, mac))
        arp_entries.sort(key=lambda x: int(x[0].split('.')[-1]))
        with open(args.output, 'w') as f:
            json.dump(arp_entries, f)
        print(f"{Style.BRIGHT}[INFO]{Style.RESET_ALL} ARP entries saved to {args.output}")
    except Exception as e:
        print(f"{Style.BRIGHT}[ERROR]{Style.RESET_ALL} SSH error: {e}")

def decode_message(args):
    mapping = load_mapping()
    reverse_mapping = {v: k for k, v in mapping.items()}
    with open(args.input, 'r') as f:
        arp_entries = json.load(f)
    decoded = ""
    for _, mac in arp_entries:
        for i in range(0, len(mac), 2):
            pair = mac[i:i+2]
            if pair in reverse_mapping:
                decoded += reverse_mapping[pair]
    with open(args.output, 'w') as f:
        f.write(decoded)
    print(f"{Style.BRIGHT}{Fore.GREEN}[MESSAGE RECEIVED]{Style.RESET_ALL} Decoded message: {decoded}")

def cleanup(args):
    print(f"{Style.BRIGHT}[INFO]{Style.RESET_ALL} Performing cleanup...")
    for idx in range(ARP_START, ARP_END + 1):
        ip = f"{args.subnet}{idx}"
        subprocess.run(["sudo", "arp", "-d", ip],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    subprocess.run(["sudo", "truncate", "-s", "0", "/var/log/auth.log"],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    print(f"{Style.BRIGHT}[INFO]{Style.RESET_ALL} Cleanup completed")

def main():
    parser = argparse.ArgumentParser(description="Initiator for network steganography")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # Encode
    encode_parser = subparsers.add_parser("encode", help="Encode message to MAC addresses")
    encode_parser.add_argument("--input", required=True, help="Input message file")
    encode_parser.add_argument("--output", required=True, help="Output encoded MAC file")

    # Add ARP
    arp_parser = subparsers.add_parser("add-arp", help="Add ARP entries")
    arp_parser.add_argument("--encoded", required=True, help="Encoded MAC file")
    arp_parser.add_argument("--subnet", required=True, help="Subnet (e.g., 172.17.0.)")

    # Send Ping
    ping_parser = subparsers.add_parser("send-ping", help="Send ping to destination")
    ping_parser.add_argument("--dest-ip", required=True, help="Destination IP")

    # Listen Ping
    listen_parser = subparsers.add_parser("listen-ping", help="Listen for ping from destination")
    listen_parser.add_argument("--dest-ip", required=True, help="Destination IP")
    listen_parser.add_argument("--subnet", required=True, help="Subnet")
    listen_parser.add_argument("--ssh-user", required=True, help="SSH username")
    listen_parser.add_argument("--ssh-pass", required=True, help="SSH password")
    listen_parser.add_argument("--output", required=True, help="Output ARP entries file")

    # Read ARP
    read_parser = subparsers.add_parser("read-arp", help="Read ARP table from destination")
    read_parser.add_argument("--dest-ip", required=True, help="Destination IP")
    read_parser.add_argument("--subnet", required=True, help="Subnet")
    read_parser.add_argument("--ssh-user", required=True, help="SSH username")
    read_parser.add_argument("--ssh-pass", required=True, help="SSH password")
    read_parser.add_argument("--output", required=True, help="Output ARP entries file")

    # Decode
    decode_parser = subparsers.add_parser("decode", help="Decode ARP entries to message")
    decode_parser.add_argument("--input", required=True, help="Input ARP entries file")
    decode_parser.add_argument("--output", required=True, help="Output decoded message file")

    # Cleanup
    cleanup_parser = subparsers.add_parser("cleanup", help="Cleanup ARP entries and logs")
    cleanup_parser.add_argument("--subnet", required=True, help="Subnet")

    args = parser.parse_args()

    if args.command == "encode":
        encode_message(args)
    elif args.command == "add-arp":
        add_arp_entries(args)
    elif args.command == "send-ping":
        send_ping(args)
    elif args.command == "listen-ping":
        listen_for_ping(args, read_arp)
    elif args.command == "read-arp":
        read_arp(args)
    elif args.command == "decode":
        decode_message(args)
    elif args.command == "cleanup":
        cleanup(args)

if __name__ == "__main__":
    main()