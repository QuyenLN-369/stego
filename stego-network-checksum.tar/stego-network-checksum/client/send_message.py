from scapy.all import *
import argparse

def text_to_bits(text):
    bits = ''.join(format(ord(c), '08b') for c in text)
    print(f"Converted message to {len(bits)} bits: {bits}")
    return bits

def send_message(input_file, dst_ip, dst_port, src_port):
    print(f"Starting to send message from {input_file} to {dst_ip}:{dst_port} with source port {src_port}")
    
    try:
        with open(input_file, 'r') as f:
            message = f.read().strip()
        print(f"Read message from {input_file}: '{message}'")
    except Exception as e:
        print(f"Error: Failed to read {input_file}: {str(e)}")
        return
    
    bits = text_to_bits(message)
    
    for i, bit in enumerate(bits):
        # Add padding with the bit (0 or 1) as a single byte
        padding = bytes([int(bit)])
        pkt = IP(dst=dst_ip)/TCP(sport=src_port, dport=dst_port, flags="S")/Raw(load=padding)
        print(f"Prepared packet {i+1}/{len(bits)}: bit={bit}, padding={padding.hex()}, {pkt.summary()}")
        
        try:
            send(pkt, verbose=0)
            print(f"Sent packet {i+1}/{len(bits)}: bit={bit}, padding={padding.hex()}")
        except Exception as e:
            print(f"Error: Failed to send packet {i+1}: {str(e)}")
    
    print(f"Finished sending {len(bits)} packets to {dst_ip}:{dst_port}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--input", required=True, help="Input text file containing message")
    parser.add_argument("-d", "--dst-ip", required=True, help="Destination IP address")
    parser.add_argument("-p", "--port", required=True, type=int, help="Destination port")
    parser.add_argument("-s", "--src-port", required=True, type=int, help="Source port")
    args = parser.parse_args()
    
    print("Starting send_message.py")
    send_message(args.input, args.dst_ip, args.port, args.src_port)
    print("Finished execution")
