import argparse
import os

def create_txt_message(message, output_file):
    with open(output_file, 'w') as f:
        f.write(message)
    print(f"Message saved to {output_file}")

def main():
    parser = argparse.ArgumentParser(description="Create .txt file with secret message")
    parser.add_argument("-m", "--message", required=True, help="Secret message")
    parser.add_argument("-o", "--output", default="secret.txt", help="Output file name (.txt)")
    
    args = parser.parse_args()
    
    if not args.output.endswith('.txt'):
        args.output += '.txt'
    
    create_txt_message(args.message, args.output)

if __name__ == "__main__":
    main()
