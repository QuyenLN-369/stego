from scapy.all import *
import argparse

def bits_to_text(bits):
    chars = [bits[i:i+8] for i in range(0, len(bits), 8)]
    message = ''.join(chr(int(c, 2)) for c in chars if len(c) == 8)
    print(f"Converted {len(bits)} bits to message: '{message}'")
    return message

def packet_callback(pkt, listen_ip, port, src_port, bits):
    if IP in pkt and TCP in pkt and Raw in pkt:
        if pkt[IP].dst == listen_ip and pkt[TCP].dport == port and pkt[TCP].sport == src_port:
            padding = pkt[Raw].load
            if len(padding) >= 1:
                bit = '1' if padding[0] == 1 else '0'
                bits.append(bit)
                print(f"Received packet: padding={padding.hex()}, extracted bit={bit}, {pkt.summary()}")

def receive_message(listen_ip, port, src_port, output_file):
    bits = []
    print(f"Starting to listen for packets on {listen_ip}:{port} from source port {src_port}")
    print("Listening for 10 seconds...")
    
    try:
        sniff(filter=f"tcp and dst host {listen_ip} and dst port {port} and src port {src_port}", 
              prn=lambda pkt: packet_callback(pkt, listen_ip, port, src_port, bits), 
              timeout=10)
    except Exception as e:
        print(f"Error: Failed to sniff packets: {str(e)}")
        return
    
    print(f"Received {len(bits)} bits: {''.join(bits)}")
    
    message = bits_to_text(''.join(bits))
    
    try:
        with open(output_file, 'w') as f:
            f.write(message)
        print(f"Saved decoded message to {output_file}: '{message}'")
    except Exception as e:
        print(f"Error: Failed to write to {output_file}: {str(e)}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-l", "--listen-ip", required=True, help="Listen IP address")
    parser.add_argument("-p", "--port", required=True, type=int, help="Destination port")
    parser.add_argument("-s", "--src-port", required=True, type=int, help="Source port")
    parser.add_argument("-o", "--output", required=True, help="Output text file")
    args = parser.parse_args()
    
    print("Starting receive_message.py")
    receive_message(args.listen_ip, args.port, args.src_port, args.output)
    print("Finished execution")
