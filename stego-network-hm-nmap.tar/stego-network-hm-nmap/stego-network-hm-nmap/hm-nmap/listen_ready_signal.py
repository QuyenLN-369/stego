import asyncio
import socket
import sys
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

async def ready_server(encoder_ip: str, token: str, ready_port: int = 9001) -> None:
    """
    Listens for a 'ready' signal from the encoder and validates IP and token.
    """
    async def handle_connection(reader, writer):
        peername = writer.get_extra_info('peername')
        if peername[0] != encoder_ip:
            logger.warning(f"Connection from unauthorized IP: {peername[0]}")
            writer.close()
            return
        try:
            data = await reader.read(100)
            message = data.decode().strip()
            if message.lower() == f'ready:{token}':
                logger.info(f"Valid 'ready' signal received from {encoder_ip}.")
            else:
                logger.error(f"Invalid signal received: {message}")
        except Exception as e:
            logger.error(f"Error handling connection: {e}")
        writer.close()

    try:
        server = await asyncio.start_server(handle_connection, '0.0.0.0', ready_port)
        logger.info(f"Listening for 'ready' signal on port {ready_port}...")
        async with server:
            await server.serve_forever()
    except Exception as e:
        logger.error(f"Failed to start server on port {ready_port}: {e}")

async def main():
    # Check for command-line arguments
    if len(sys.argv) != 3:
        print("[ERROR] Usage: python3 listen_ready_signal.py <encoder_ip> <shared_token>")
        print("[EXAMPLE] python3 listen_ready_signal.py 172.17.0.2 secret123")
        sys.exit(1)

    encoder_ip = sys.argv[1]
    token = sys.argv[2]

    # Validate IP format
    try:
        socket.inet_aton(encoder_ip)
    except socket.error:
        logger.error(f"Invalid IP address: {encoder_ip}")
        sys.exit(1)

    # Start the server
    await ready_server(encoder_ip, token)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Shutting down...")
    except Exception as e:
        logger.error(f"Unexpected error: {e}")