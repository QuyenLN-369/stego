import sys

def message_to_ports(message, base_port=10000):
    """
    Converts a message to a list of port numbers using position and character code.
    Returns a list of valid ports (10000–65535).
    """
    ports = []
    for position, char in enumerate(message):
        ascii_value = ord(char)
        port_offset = position * 256 + ascii_value
        port = base_port + port_offset
        if base_port <= port <= 65535:
            ports.append(port)
        else:
            print(f"[ERROR] Port number {port} for character '{char}' at position {position} is invalid. Skipping.")
    return ports

def save_ports_to_file(ports, filename):
    """
    Saves the list of ports to the specified file.
    """
    try:
        with open(filename, 'w') as f:
            f.write(','.join(str(port) for port in ports))
        print(f"[INFO] Ports saved to {filename}")
    except Exception as e:
        print(f"[ERROR] Failed to save ports to {filename}: {e}")

def main():
    # Check for command-line argument for output file
    output_file = 'port_open.txt'  # Default filename
    if len(sys.argv) > 1:
        output_file = sys.argv[1]

    # Get input message from user
    message = input("[INPUT] Enter the message to convert to ports (max 100 characters): ").strip()
    
    # Validate message length
    if len(message) > 100:
        print("[ERROR] Message is too long. Please enter up to 100 characters.")
        return
    
    # Convert message to ports
    ports = message_to_ports(message)
    
    # Display results
    if ports:
        print(f"[INFO] Message '{message}' converted to ports: {ports}")
        print(f"[INFO] Total ports: {len(ports)}")
        # Save ports to file
        save_ports_to_file(ports, output_file)
    else:
        print("[INFO] No valid ports generated. Check your input message.")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[BYE] Exiting...")