import asyncio
import socket
import sys
import subprocess
import re
import logging
from typing import List

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def read_ports_from_file(filename: str) -> List[int]:
    """
    Reads a comma-separated list of ports from the specified file.
    Returns a list of valid ports (10000–65535).
    """
    try:
        with open(filename, 'r') as f:
            ports_str = f.read().strip()
        ports = [int(p.strip()) for p in ports_str.split(',') if p.strip().isdigit()]
        if not all(10000 <= p <= 65535 for p in ports):
            logger.error("All ports in the file must be between 10000 and 65535.")
            return []
        return ports
    except FileNotFoundError:
        logger.error(f"File {filename} not found.")
        return []
    except ValueError:
        logger.error(f"Invalid format in {filename}. Expected comma-separated port numbers.")
        return []
    except Exception as e:
        logger.error(f"Failed to read ports from {filename}: {e}")
        return []

async def open_port(port: int, shutdown_event: asyncio.Event) -> None:
    """
    Opens a TCP port asynchronously and keeps it open until shutdown_event is set.
    """
    try:
        server = await asyncio.start_server(lambda r, w: w.close(), '0.0.0.0', port)
        logger.info(f"Port {port} is open.")
        async with server:
            await shutdown_event.wait()
    except Exception as e:
        logger.error(f"Could not open port {port}: {e}")

async def send_ready_signal(decoder_ip: str, token: str, decoder_port: int = 9001) -> None:
    """
    Sends a 'ready' signal to the decoder with a shared secret token.
    """
    try:
        reader, writer = await asyncio.open_connection(decoder_ip, decoder_port)
        writer.write(f'ready:{token}'.encode())
        await writer.drain()
        logger.info(f"Ready signal sent to {decoder_ip}:{decoder_port}.")
        writer.close()
        await writer.wait_closed()
    except Exception as e:
        logger.error(f"Failed to send ready signal to {decoder_ip}:{decoder_port}: {e}")

async def control_server(shutdown_event: asyncio.Event, decoder_ip: str, token: str, control_port: int = 9000) -> None:
    """
    Listens for a shutdown signal from the decoder and filters by IP and token.
    """
    async def handle_control(reader, writer):
        peername = writer.get_extra_info('peername')
        if peername[0] != decoder_ip:
            logger.warning(f"Connection from unauthorized IP: {peername[0]}")
            writer.close()
            return
        try:
            data = await reader.read(100)
            message = data.decode().strip()
            if message.lower() == f'shutdown:{token}':
                logger.info("Shutdown signal received from decoder.")
                shutdown_event.set()
            else:
                logger.error(f"Invalid token received: {message}")
        except Exception as e:
            logger.error(f"Error handling control connection: {e}")
        writer.close()

    try:
        server = await asyncio.start_server(handle_control, '0.0.0.0', control_port)
        logger.info(f"Control server listening on port {control_port}.")
        async with server:
            await server.serve_forever()
    except Exception as e:
        logger.error(f"Failed to start control server on port {control_port}: {e}")

def check_ports_with_socket(ports: List[int], host: str) -> List[int]:
    """
    Checks which ports are open on the specified host using socket connections.
    Returns a list of open ports.
    """
    open_ports = []
    for port in ports:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(2)  # Increased timeout for Docker networks
            result = s.connect_ex((host, port))
            if result == 0:
                open_ports.append(port)
            else:
                logger.debug(f"Port {port} on {host} is closed or unreachable (error code: {result}).")
    return open_ports

def check_ports_with_nmap(ports: List[int], host: str) -> List[int]:
    """
    Checks which ports are open on the specified host using nmap.
    Requires nmap to be installed. Returns a list of open ports.
    """
    try:
        port_range = f"{min(ports)}-{max(ports)}" if ports else "10000-65535"
        logger.debug(f"Running nmap scan: nmap -p {port_range} {host}")
        result = subprocess.run(
            ['nmap', '-p', port_range, host],
            capture_output=True,
            text=True,
            timeout=60  # Timeout for nmap scan
        )
        output = result.stdout
        logger.debug(f"nmap output:\n{output}")
        open_ports = []
        for line in output.splitlines():
            match = re.search(r'(\d+)/tcp\s+open', line)
            if match:
                port = int(match.group(1))
                if port in ports:
                    open_ports.append(port)
        return open_ports
    except FileNotFoundError:
        logger.error("nmap is not installed. Install with 'sudo apt-get install nmap' or use socket-based checking.")
        return []
    except subprocess.TimeoutExpired:
        logger.error(f"nmap scan timed out for {host} on ports {port_range}.")
        return []
    except Exception as e:
        logger.error(f"Failed to run nmap: {e}")
        return []

async def main() -> None:
    # Check for command-line arguments
    if len(sys.argv) < 4 or len(sys.argv) > 5:
        print("[ERROR] Usage: python3 open_and_check_ports_with_ip_and_signals.py <encoder_ip> <decoder_ip> <shared_token> [<port_file>]")
        print("[EXAMPLE] python3 open_and_check_ports_with_ip_and_signals.py 172.17.0.2 172.17.0.3 secret123 port_open.txt")
        sys.exit(1)

    encoder_ip = sys.argv[1]
    decoder_ip = sys.argv[2]
    token = sys.argv[3]
    port_file = sys.argv[4] if len(sys.argv) == 5 else 'port_open.txt'

    # Validate IP format
    for ip in [encoder_ip, decoder_ip]:
        try:
            socket.inet_aton(ip)
        except socket.error:
            logger.error(f"Invalid IP address: {ip}")
            sys.exit(1)

    # Initialize shutdown event
    shutdown_event = asyncio.Event()

    # Read ports from file
    ports = read_ports_from_file(port_file)
    if not ports:
        logger.error("No valid ports found in the file. Exiting...")
        return

    logger.info(f"Ports to open on {encoder_ip}: {ports}")

    # Open ports
    tasks = [asyncio.create_task(open_port(port, shutdown_event)) for port in ports]

    # Start control server for shutdown signal
    control_task = asyncio.create_task(control_server(shutdown_event, decoder_ip, token))

    # Send ready signal to decoder
    await send_ready_signal(decoder_ip, token)

    # Allow checking ports
    check_method = input("[INPUT] Check open ports? (socket/nmap/none): ").strip().lower()
    if check_method in ['socket', 'nmap']:
        open_ports = (
            check_ports_with_socket(ports, encoder_ip) if check_method == 'socket' else
            check_ports_with_nmap(ports, encoder_ip)
        )
        if open_ports:
            logger.info(f"Open ports on {encoder_ip}: {open_ports}")
            logger.info(f"Total open ports: {len(open_ports)}")
        else:
            logger.warning(f"No ports are open on {encoder_ip} or check failed. Check firewall, Docker port mappings, or network settings.")

    # Wait for shutdown signal or user input
    logger.info("Ports are open. Waiting for shutdown signal from decoder or press Enter to close ports and exit.")
    try:
        await asyncio.gather(
            asyncio.create_task(shutdown_event.wait()),
            asyncio.create_task(asyncio.get_event_loop().run_in_executor(None, input))
        )
    except KeyboardInterrupt:
        logger.info("User interrupted. Shutting down...")

    # Cancel tasks
    for task in tasks:
        task.cancel()
    control_task.cancel()
    logger.info("All ports have been closed.")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Shutting down...")
    except Exception as e:
        logger.error(f"Unexpected error: {e}")